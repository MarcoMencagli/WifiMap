# WifiMap
Project for the "Software Engineering" course, University of Perugia (2018-2019)
